package com.demo;

public abstract class GreeterBase implements GreetInterface {

    protected int greetCount = 0;
}
